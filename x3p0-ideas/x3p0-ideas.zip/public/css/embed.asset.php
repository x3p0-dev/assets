<?php return array('dependencies' => array(), 'version' => 'b1a855c86c3bc232f73e');
