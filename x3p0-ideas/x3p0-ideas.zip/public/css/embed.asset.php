<?php return array('dependencies' => array(), 'version' => '205b40eb38fa5cf75384');
