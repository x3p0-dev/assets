<?php return array('dependencies' => array(), 'version' => 'a92ea79a9eb8e3d36faf');
