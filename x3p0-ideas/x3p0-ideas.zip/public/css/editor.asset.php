<?php return array('dependencies' => array(), 'version' => '9b6f17b36c36565fbd6c');
