<?php return array('dependencies' => array(), 'version' => 'd96f98fee2d3dde060e5');
