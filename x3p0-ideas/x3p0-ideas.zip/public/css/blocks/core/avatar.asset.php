<?php return array('dependencies' => array(), 'version' => 'b5db192c873cf02cdf6a');
