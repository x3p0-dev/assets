<?php return array('dependencies' => array(), 'version' => 'e23a2b6e1727cc51a94e');
