<?php return array('dependencies' => array(), 'version' => '6c64d67219f6b1bbc3af');
