<?php return array('dependencies' => array(), 'version' => '2d60bf9a32f3e56aca4a');
