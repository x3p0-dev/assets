<?php return array('dependencies' => array(), 'version' => '6c779c31071a2ce02d83');
