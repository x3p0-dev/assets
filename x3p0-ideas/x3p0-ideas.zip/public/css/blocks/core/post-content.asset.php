<?php return array('dependencies' => array(), 'version' => 'ca172bfbcb4882d2e600');
