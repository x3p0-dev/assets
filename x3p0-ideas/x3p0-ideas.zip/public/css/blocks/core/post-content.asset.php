<?php return array('dependencies' => array(), 'version' => '3c04ad6c9036a329af7f');
