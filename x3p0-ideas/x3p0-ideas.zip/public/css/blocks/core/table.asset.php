<?php return array('dependencies' => array(), 'version' => '94c4a5ec62a859ed2f36');
