<?php return array('dependencies' => array(), 'version' => '98d9cd161fc70218f47e');
