<?php return array('dependencies' => array(), 'version' => '9973641ee36ed7cf5ec3');
