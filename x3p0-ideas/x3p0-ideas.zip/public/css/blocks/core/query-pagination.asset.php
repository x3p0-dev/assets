<?php return array('dependencies' => array(), 'version' => 'aaf7525141bfc70d684e');
