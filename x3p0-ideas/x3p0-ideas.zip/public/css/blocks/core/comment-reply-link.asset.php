<?php return array('dependencies' => array(), 'version' => 'e6336e4ad1ba0c8080f9');
