<?php return array('dependencies' => array(), 'version' => 'c1c8f82fd3f87188138b');
