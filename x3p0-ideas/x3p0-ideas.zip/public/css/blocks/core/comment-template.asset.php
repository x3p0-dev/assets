<?php return array('dependencies' => array(), 'version' => '8d9e33780412a163cb0b');
