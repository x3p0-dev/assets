<?php return array('dependencies' => array(), 'version' => '48356065067511b1cd29');
