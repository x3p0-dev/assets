<?php return array('dependencies' => array(), 'version' => '7948c61c4afac603c126');
