<?php return array('dependencies' => array(), 'version' => 'a2b4efac8e8a7d177acd');
