<?php return array('dependencies' => array(), 'version' => 'b56c6114d246b7a3daae');
