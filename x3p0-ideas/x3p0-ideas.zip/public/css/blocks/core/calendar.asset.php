<?php return array('dependencies' => array(), 'version' => 'd5db1a1f4adc218c7cb2');
