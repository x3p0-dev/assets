<?php return array('dependencies' => array(), 'version' => 'e5152a7e083caf1619aa');
