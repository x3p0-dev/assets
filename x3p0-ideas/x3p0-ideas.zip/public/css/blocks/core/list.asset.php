<?php return array('dependencies' => array(), 'version' => '08cafdb482f4da09c026');
