<?php return array('dependencies' => array(), 'version' => '5f47269b108bbcf8a863');
