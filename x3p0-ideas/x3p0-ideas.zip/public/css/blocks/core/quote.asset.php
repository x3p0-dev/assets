<?php return array('dependencies' => array(), 'version' => 'ffb612091010332b1632');
