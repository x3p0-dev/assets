<?php return array('dependencies' => array(), 'version' => 'a8a830940b74375b30a4');
