<?php return array('dependencies' => array(), 'version' => '2eec6e25847841f92acc');
