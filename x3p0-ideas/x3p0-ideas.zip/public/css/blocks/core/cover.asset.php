<?php return array('dependencies' => array(), 'version' => 'fe99f23092f9f439b3f0');
