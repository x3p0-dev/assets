<?php return array('dependencies' => array(), 'version' => '3e89eaef195cc1d267a3');
