<?php return array('dependencies' => array(), 'version' => 'ef2a1925a00853298403');
