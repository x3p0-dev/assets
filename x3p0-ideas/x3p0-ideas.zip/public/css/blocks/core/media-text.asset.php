<?php return array('dependencies' => array(), 'version' => 'e05b27a69519095985f9');
