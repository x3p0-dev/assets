<?php return array('dependencies' => array(), 'version' => '56535e8443a4a298d794');
