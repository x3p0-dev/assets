<?php return array('dependencies' => array(), 'version' => '42fe61d99316ebdfcc28');
