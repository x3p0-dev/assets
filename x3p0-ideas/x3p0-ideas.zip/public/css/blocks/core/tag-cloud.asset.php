<?php return array('dependencies' => array(), 'version' => '14d7cd5ec07c3140bdec');
