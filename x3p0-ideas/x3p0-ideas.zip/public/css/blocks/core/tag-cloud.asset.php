<?php return array('dependencies' => array(), 'version' => '435e8dec9726db81dc5c');
