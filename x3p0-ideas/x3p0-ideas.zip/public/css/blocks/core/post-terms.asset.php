<?php return array('dependencies' => array(), 'version' => 'd6f3c391418e78d753c6');
