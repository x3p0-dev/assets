<?php return array('dependencies' => array(), 'version' => 'b03f3fcfeba45f0443b1');
