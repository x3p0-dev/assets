<?php return array('dependencies' => array(), 'version' => '03dcc47f79c426c77e80');
