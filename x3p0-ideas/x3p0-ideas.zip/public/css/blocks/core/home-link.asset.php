<?php return array('dependencies' => array(), 'version' => 'fc59e1b5ccf92cde8c10');
