<?php return array('dependencies' => array(), 'version' => '72551ad8dcf35feb7088');
