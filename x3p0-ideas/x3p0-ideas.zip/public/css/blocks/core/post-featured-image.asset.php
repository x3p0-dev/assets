<?php return array('dependencies' => array(), 'version' => '3bfd3764d1fca55ec32e');
