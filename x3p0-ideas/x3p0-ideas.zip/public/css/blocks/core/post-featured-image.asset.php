<?php return array('dependencies' => array(), 'version' => '5621e724afc5d49e50f2');
