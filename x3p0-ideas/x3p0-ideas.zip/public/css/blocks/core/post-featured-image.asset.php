<?php return array('dependencies' => array(), 'version' => '24f1df4b431e38511a39');
