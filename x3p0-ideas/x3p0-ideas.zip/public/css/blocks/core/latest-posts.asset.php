<?php return array('dependencies' => array(), 'version' => '55748a27f5e09a02d4fd');
