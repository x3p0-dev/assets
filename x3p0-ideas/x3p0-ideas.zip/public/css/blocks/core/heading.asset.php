<?php return array('dependencies' => array(), 'version' => '6f90d1dda575b5826b38');
