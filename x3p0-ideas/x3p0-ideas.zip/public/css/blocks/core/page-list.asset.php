<?php return array('dependencies' => array(), 'version' => 'ca0d7df640dfa6fefed3');
