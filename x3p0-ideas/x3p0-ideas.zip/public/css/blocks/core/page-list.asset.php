<?php return array('dependencies' => array(), 'version' => '13002fbffb5ee0c8d2bc');
