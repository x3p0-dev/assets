<?php return array('dependencies' => array(), 'version' => '65d54aa9106caa7ffd93');
