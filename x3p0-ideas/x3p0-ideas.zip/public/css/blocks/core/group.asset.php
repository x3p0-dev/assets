<?php return array('dependencies' => array(), 'version' => 'ecf9ba6c29e2ddeb2e40');
