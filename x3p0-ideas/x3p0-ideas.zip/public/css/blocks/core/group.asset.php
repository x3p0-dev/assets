<?php return array('dependencies' => array(), 'version' => '5cfcfda61ea8f069d2f0');
