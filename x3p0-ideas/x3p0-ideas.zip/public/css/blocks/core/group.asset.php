<?php return array('dependencies' => array(), 'version' => '5f0590c1d0b590b5058f');
