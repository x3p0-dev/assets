<?php return array('dependencies' => array(), 'version' => '5d2416608e66531364a2');
