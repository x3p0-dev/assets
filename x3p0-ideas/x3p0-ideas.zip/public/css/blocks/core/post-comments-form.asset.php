<?php return array('dependencies' => array(), 'version' => '2e0f1000a46d878a6046');
