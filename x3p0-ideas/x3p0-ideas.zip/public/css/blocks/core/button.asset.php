<?php return array('dependencies' => array(), 'version' => 'ddd022588be9f85297e0');
