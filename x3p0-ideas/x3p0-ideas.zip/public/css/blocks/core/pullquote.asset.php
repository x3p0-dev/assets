<?php return array('dependencies' => array(), 'version' => 'd223ed84e630972f65fb');
