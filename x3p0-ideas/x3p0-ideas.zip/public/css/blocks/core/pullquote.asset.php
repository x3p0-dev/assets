<?php return array('dependencies' => array(), 'version' => 'cbf30c539b2254ba4960');
