<?php return array('dependencies' => array(), 'version' => '52a1897b86b669999844');
