<?php return array('dependencies' => array(), 'version' => '8a7da49046cc1e353945');
