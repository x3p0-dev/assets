<?php return array('dependencies' => array(), 'version' => 'df417e6963157cbe9631');
