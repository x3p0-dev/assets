<?php return array('dependencies' => array(), 'version' => '32a1e16a7fe0004d4c3e');
