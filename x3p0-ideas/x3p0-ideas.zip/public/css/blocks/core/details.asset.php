<?php return array('dependencies' => array(), 'version' => '0fdbbb76b09e8db2ab4d');
