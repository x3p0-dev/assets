<?php return array('dependencies' => array(), 'version' => '7ece732e06736923a697');
