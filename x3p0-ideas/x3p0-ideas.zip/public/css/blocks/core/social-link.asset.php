<?php return array('dependencies' => array(), 'version' => 'eccc3c185fb6ecfc77a4');
