<?php return array('dependencies' => array(), 'version' => '38cff1ed1bd4226c71eb');
