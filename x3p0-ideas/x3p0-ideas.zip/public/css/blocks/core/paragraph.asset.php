<?php return array('dependencies' => array(), 'version' => 'ad4df5ddd90e17ae2b6e');
