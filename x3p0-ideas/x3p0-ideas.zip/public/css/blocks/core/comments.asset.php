<?php return array('dependencies' => array(), 'version' => '10162631536081cb7bad');
