<?php return array('dependencies' => array(), 'version' => 'af216d846480a230e975');
