<?php return array('dependencies' => array(), 'version' => '3b33e90790a63025bf0b');
