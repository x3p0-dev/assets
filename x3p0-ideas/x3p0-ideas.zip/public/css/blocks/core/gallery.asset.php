<?php return array('dependencies' => array(), 'version' => '427a14355ad006d54dcb');
