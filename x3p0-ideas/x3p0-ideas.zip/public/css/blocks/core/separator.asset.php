<?php return array('dependencies' => array(), 'version' => '5a5c6c1446f25ca60fd5');
