<?php return array('dependencies' => array(), 'version' => 'a7e26803b2143948aab6');
