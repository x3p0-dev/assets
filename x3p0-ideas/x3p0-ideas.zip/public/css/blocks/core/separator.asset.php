<?php return array('dependencies' => array(), 'version' => 'c9c18b784e011816227e');
