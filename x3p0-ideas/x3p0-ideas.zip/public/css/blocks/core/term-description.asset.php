<?php return array('dependencies' => array(), 'version' => 'a51d374fd1861dbd4402');
