<?php return array('dependencies' => array(), 'version' => '4a59230ea1cb6f9910c3');
