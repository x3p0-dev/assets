<?php return array('dependencies' => array(), 'version' => '24def7f1f4395611ec99');
