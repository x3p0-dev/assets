<?php return array('dependencies' => array(), 'version' => '32f63ceda3c706284513');
